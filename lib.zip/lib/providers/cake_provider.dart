import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../models/cake_model.dart';

class CakeProvider with ChangeNotifier {
  List<CakeModel> _cakes = [];
  bool _isLoading = false;

  List<CakeModel> get cakes => _cakes;
  bool get isLoading => _isLoading;

  Future<void> fetchCakes() async {
    _isLoading = true;
    notifyListeners();

    try {
      final snapshot = await FirebaseFirestore.instance.collection('cakes').get();
      _cakes = snapshot.docs.map((doc) => CakeModel.fromMap(doc.data())).toList();
    } catch (e) {
      print('Error fetching cakes: $e');
    }

    _isLoading = false;
    notifyListeners();
  }
}